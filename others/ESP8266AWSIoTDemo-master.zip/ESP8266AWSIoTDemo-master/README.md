# ESP8266AWSIoTDemo
Simple demo to push static data from ESP8266 to AWS IoT platform

Requirements: <https://github.com/heskew/aws-sdk-arduino>
